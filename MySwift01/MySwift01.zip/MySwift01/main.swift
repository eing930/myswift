//
//  main.swift
//  MySwift01
//
//  Created by user20 on 2017/9/6.
//  Copyright © 2017年 Yvonne Big. All rights reserved.
//
//
import Foundation
print("hello")

//
//var Var1 = true //false=>Bool
//var Var2 = 123;
//var Var3 = 12.3;
//var Var4 = "Brad"
//print(type(of: Var4))
//
//typealias byte = Int8
//var Var5:byte = 12
//print(type(of:Var5))
//
//print("My name is" + Var4)
//print("My name is\(Var4)")


